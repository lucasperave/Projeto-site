# Multiverse Explorer — Rick and Morty

Projeto Front-End acadêmico desenvolvido com HTML, CSS e JavaScript puro.

## Estrutura
- `index.html` — estrutura da página.
- `css/style.css` — identidade visual, cards e responsividade.
- `js/script.js` — consumo da API, criação dinâmica dos cards, busca, filtros, paginação e favoritos.

## Como executar
1. Baixe ou clone o repositório.
2. Abra `index.html` no navegador (recomendado usar Live Server no VS Code).
3. Mantenha a conexão com a internet ativa para consultar a API e carregar as imagens.

## Funcionalidades
- Consumo da Rick and Morty API com `fetch`.
- Cards criados com `document.createElement` e inseridos com `appendChild`.
- Pesquisa por nome e filtro por status.
- Paginação de resultados.
- Favoritos com armazenamento local no navegador (`localStorage`).
- Layout adaptável a desktop e dispositivos móveis.

## API
https://rickandmortyapi.com/
Endpoint: https://rickandmortyapi.com/api/character
