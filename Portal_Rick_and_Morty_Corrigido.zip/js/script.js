const API_URL = "https://rickandmortyapi.com/api/character";

const elements = {
  grid: document.getElementById("characterGrid"),
  message: document.getElementById("message"),
  resultCount: document.getElementById("resultCount"),
  pageIndicator: document.getElementById("pageIndicator"),
  pageLabel: document.getElementById("pageLabel"),
  searchInput: document.getElementById("searchInput"),
  statusFilter: document.getElementById("statusFilter"),
  searchButton: document.getElementById("searchButton"),
  clearSearch: document.getElementById("clearSearch"),
  favoritesButton: document.getElementById("favoritesButton"),
  favoritesCount: document.getElementById("favoritesCount"),
  prevButton: document.getElementById("prevButton"),
  nextButton: document.getElementById("nextButton")
};

const state = {
  page: 1,
  totalPages: 1,
  name: "",
  status: "",
  showingFavorites: false,
  favorites: loadFavorites()
};

function loadFavorites() {
  try {
    const saved = JSON.parse(localStorage.getItem("rm-favorites") || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function saveFavorites() {
  try {
    localStorage.setItem("rm-favorites", JSON.stringify(state.favorites));
  } catch (error) {
    console.warn("Não foi possível salvar os favoritos neste navegador.", error);
  }
  updateFavoritesCounter();
}

function updateFavoritesCounter() {
  elements.favoritesCount.textContent = state.favorites.length;
  elements.favoritesButton.classList.toggle("active", state.showingFavorites);
  elements.favoritesButton.setAttribute("aria-pressed", String(state.showingFavorites));
}

function showMessage(title, subtitle = "", isError = false) {
  elements.message.hidden = false;
  elements.message.classList.toggle("error", isError);
  elements.message.replaceChildren();

  const loader = document.createElement("span");
  loader.className = "loader";
  const heading = document.createElement("strong");
  heading.textContent = title;
  elements.message.append(loader, heading);

  if (subtitle) {
    const small = document.createElement("small");
    small.textContent = subtitle;
    elements.message.appendChild(small);
  }
}

function translateStatus(status) {
  return ({ Alive: "Vivo", Dead: "Morto", unknown: "Desconhecido" })[status] || status;
}

function createDetailRow(label, value, status = false) {
  const row = document.createElement("div");
  row.className = "detail-row";

  const title = document.createElement("span");
  title.className = "detail-label";
  title.textContent = label;

  const content = document.createElement("strong");
  content.className = "detail-value";

  if (status) {
    const statusClass = value === "Alive" ? "status-alive"
      : value === "Dead" ? "status-dead" : "status-unknown";
    content.classList.add("status-value", statusClass);
    const dot = document.createElement("i");
    dot.className = "status-dot";
    const text = document.createElement("span");
    text.textContent = translateStatus(value);
    content.append(dot, text);
  } else {
    content.textContent = value || "Não informado";
    content.title = value || "Não informado";
  }

  row.append(title, content);
  return row;
}

function toggleFavorite(character) {
  const exists = state.favorites.some(item => item.id === character.id);

  if (exists) {
    state.favorites = state.favorites.filter(item => item.id !== character.id);
  } else {
    state.favorites.push({
      id: character.id,
      name: character.name,
      image: character.image,
      status: character.status,
      species: character.species,
      origin: character.origin?.name || "Desconhecida",
      location: character.location?.name || "Desconhecida"
    });
  }

  saveFavorites();

  if (state.showingFavorites) {
    renderFavorites();
  } else {
    const button = elements.grid.querySelector(`[data-favorite-id="${character.id}"]`);
    if (button) {
      const favorite = state.favorites.some(item => item.id === character.id);
      button.classList.toggle("is-favorite", favorite);
      button.textContent = favorite ? "♥" : "♡";
      button.setAttribute("aria-pressed", String(favorite));
      button.setAttribute("aria-label", favorite ? "Remover dos favoritos" : "Adicionar aos favoritos");
    }
  }
}

function createCharacterCard(character) {
  // Os cards são construídos dinamicamente a partir dos dados da API.
  const card = document.createElement("article");
  card.className = "character-card";

  const top = document.createElement("div");
  top.className = "card-top";

  const name = document.createElement("h3");
  name.className = "card-name";
  name.textContent = character.name;
  name.title = character.name;

  const favoriteButton = document.createElement("button");
  const isFavorite = state.favorites.some(item => item.id === character.id);
  favoriteButton.type = "button";
  favoriteButton.className = `favorite-button${isFavorite ? " is-favorite" : ""}`;
  favoriteButton.textContent = isFavorite ? "♥" : "♡";
  favoriteButton.dataset.favoriteId = character.id;
  favoriteButton.setAttribute("aria-label", isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos");
  favoriteButton.setAttribute("aria-pressed", String(isFavorite));
  favoriteButton.addEventListener("click", () => toggleFavorite(character));

  top.append(name, favoriteButton);

  const imageWrap = document.createElement("div");
  imageWrap.className = "card-image-wrap";

  const image = document.createElement("img");
  image.className = "card-image";
  image.src = character.image;
  image.alt = `Imagem de ${character.name}`;
  image.loading = "lazy";
  image.onerror = () => {
    image.alt = `Imagem indisponível para ${character.name}`;
    image.style.opacity = "0.25";
  };

  const id = document.createElement("span");
  id.className = "card-id";
  id.textContent = `ID / ${character.id}`;
  imageWrap.append(image, id);

  const details = document.createElement("div");
  details.className = "card-details";
  details.append(
    createDetailRow("STATUS", character.status, true),
    createDetailRow("ESPÉCIE", character.species),
    createDetailRow("ORIGEM", typeof character.origin === "string" ? character.origin : (character.origin?.name || "Desconhecida")),
    createDetailRow("LOCALIZAÇÃO", typeof character.location === "string" ? character.location : (character.location?.name || "Desconhecida"))
  );

  card.append(top, imageWrap, details);
  return card;
}

function renderCharacters(characters) {
  elements.grid.replaceChildren();
  const fragment = document.createDocumentFragment();

  characters.forEach(character => {
    fragment.appendChild(createCharacterCard(character));
  });

  // appendChild adiciona ao DOM os cards criados com createElement.
  elements.grid.appendChild(fragment);
  elements.message.hidden = true;
}

function renderFavorites() {
  elements.grid.replaceChildren();
  elements.pageIndicator.textContent = "";

  if (state.favorites.length === 0) {
    elements.resultCount.textContent = "0 PERSONAGENS FAVORITADOS";
    showMessage("Você ainda não salvou favoritos.", "Clique no coração de um personagem para adicioná-lo.");
    elements.prevButton.disabled = true;
    elements.nextButton.disabled = true;
    elements.pageLabel.textContent = "FAVORITOS";
    return;
  }

  renderCharacters(state.favorites);
  elements.resultCount.textContent = `${state.favorites.length} PERSONAGEM(NS) FAVORITADO(S)`;
  elements.pageLabel.textContent = "FAVORITOS";
  elements.prevButton.disabled = true;
  elements.nextButton.disabled = true;
}

async function loadCharacters(page = 1) {
  state.page = page;
  elements.grid.replaceChildren();
  showMessage("Carregando personagens...", "Consultando a Rick and Morty API");
  elements.resultCount.textContent = "CONECTANDO À API...";
  elements.pageIndicator.textContent = "";
  elements.prevButton.disabled = true;
  elements.nextButton.disabled = true;
  elements.pageLabel.textContent = `PÁGINA ${page}`;

  const params = new URLSearchParams({ page: String(page) });
  if (state.name) params.set("name", state.name);
  if (state.status) params.set("status", state.status);

  try {
    const response = await fetch(`${API_URL}?${params.toString()}`);

    if (response.status === 404) {
      throw new Error("Nenhum personagem encontrado. Tente alterar a busca ou o filtro.");
    }
    if (!response.ok) {
      throw new Error(`A API retornou um erro (${response.status}). Tente novamente.`);
    }

    const data = await response.json();
    state.totalPages = data.info.pages;

    renderCharacters(data.results);
    elements.resultCount.textContent = `${data.info.count} PERSONAGEM(NS) ENCONTRADO(S)`;
    elements.pageIndicator.textContent = `${data.results.length} NESTA PÁGINA`;
    elements.pageLabel.textContent = `PÁGINA ${state.page} / ${state.totalPages}`;
    elements.prevButton.disabled = state.page <= 1;
    elements.nextButton.disabled = state.page >= state.totalPages;
  } catch (error) {
    elements.grid.replaceChildren();
    showMessage(error.message || "Falha de conexão. Verifique sua internet.", "Você pode tentar novamente pelo botão Buscar.", true);
    elements.resultCount.textContent = "NÃO FOI POSSÍVEL CARREGAR OS DADOS";
    elements.pageIndicator.textContent = "";
    elements.pageLabel.textContent = `PÁGINA ${state.page}`;
  }
}

function applySearch() {
  state.name = elements.searchInput.value.trim();
  state.status = elements.statusFilter.value;
  state.showingFavorites = false;
  updateFavoritesCounter();
  loadCharacters(1);
}

elements.searchButton.addEventListener("click", applySearch);
elements.searchInput.addEventListener("keydown", event => {
  if (event.key === "Enter") applySearch();
});
elements.statusFilter.addEventListener("change", applySearch);

elements.clearSearch.addEventListener("click", () => {
  elements.searchInput.value = "";
  state.name = "";
  applySearch();
  elements.searchInput.focus();
});

elements.favoritesButton.addEventListener("click", () => {
  state.showingFavorites = !state.showingFavorites;
  updateFavoritesCounter();

  if (state.showingFavorites) {
    renderFavorites();
  } else {
    state.name = elements.searchInput.value.trim();
    state.status = elements.statusFilter.value;
    loadCharacters(1);
  }
});

elements.prevButton.addEventListener("click", () => {
  if (!state.showingFavorites && state.page > 1) loadCharacters(state.page - 1);
});
elements.nextButton.addEventListener("click", () => {
  if (!state.showingFavorites && state.page < state.totalPages) loadCharacters(state.page + 1);
});

updateFavoritesCounter();
loadCharacters();
